package com.app.controller;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.dao.IEmpDao;
import com.app.pojos.Employee;

@Controller
@RequestMapping("/Employee")
public class EmpController {
	@Autowired
	IEmpDao dao;

	public EmpController() {
		System.out.println("In Emp Controller");
	}

	@GetMapping("/Register")
	public String ShowRegisterForm(ModelMap map) {
		map.addAttribute("employee", new Employee());
		return "/Employee/Register";
	}

	@PostMapping("/Register")
	public String SubmitForm(Employee e, ModelMap map) {
		try {
			System.out.println(e);
			dao.registerEmp(e);

		} catch (HibernateException ex) {
			map.addAttribute("error", ex.getMessage());
			return "/Employee/Register";
		}

		if (e.getUserRole().equalsIgnoreCase("admin"))
			return "redirect:/Employee/List";
		else
			return "redirect:/Employee/Details?empId=" + e.getEmpId();
	}

	@GetMapping("/List")
	public String ShowList(ModelMap map) {
		try {
			map.addAttribute("emp_list", dao.getAllEmps());
		} catch (HibernateException ex) {
			map.addAttribute("error", ex.getMessage());
			return "/Employee/Register";
		}

		return "/Employee/List";
	}

	@GetMapping("/Details")
	public String ShowDetails(@RequestParam Integer empId, ModelMap map) {
		try {
			map.addAttribute("emp_details", dao.getEmpDetails(empId));
		} catch (HibernateException ex) {
			map.addAttribute("error", ex.getMessage());
			return "/Employee/Register";
		}
		return "/Employee/Details";
	}

}
