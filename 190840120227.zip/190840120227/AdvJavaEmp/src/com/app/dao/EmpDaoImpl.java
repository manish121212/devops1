package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.app.pojos.Employee;

@Repository
@Transactional
public class EmpDaoImpl implements IEmpDao {
	@Autowired
	private SessionFactory sf;

	@Override
	public int registerEmp(Employee e) {
		System.out.println("in Register Employee" + e);
		sf.getCurrentSession().save(e);
		return 0;
	}

	@Override
	public Employee getEmpDetails(int empId) {
		return sf.getCurrentSession().createQuery("select e from Employee e where id=:eid", Employee.class)
				.setParameter("eid", empId).getSingleResult();
	}

	@Override
	public List<Employee> getAllEmps() {
		return sf.getCurrentSession().createQuery("select e from Employee e", Employee.class).getResultList();
	}

}
