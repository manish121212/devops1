package com.app.dao;

import java.util.List;

import com.app.pojos.*;

public interface IEmpDao {

	public int registerEmp(Employee e);

	public Employee getEmpDetails(int empId);

	public List<Employee> getAllEmps();

}
