package com.app.pojos;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer empId;

	@Column(length = 15)
	private String name;

	@Column(length = 25)
	private String email;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate joinDate;

	private boolean isPermanent;

	@Column(length = 10)
	private String UserRole;

	public Employee() {
	}

	public Employee(String name, String email, LocalDate joinDate, boolean isPermanent, String userRole) {
		super();
		this.name = name;
		this.email = email;
		this.joinDate = joinDate;
		this.isPermanent = isPermanent;
		UserRole = userRole;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(LocalDate joinDate) {
		this.joinDate = joinDate;
	}

	public boolean isPermanent() {
		return isPermanent;
	}

	public void setPermanent(boolean isPermanent) {
		this.isPermanent = isPermanent;
	}

	public String getUserRole() {
		return UserRole;
	}

	public void setUserRole(String userRole) {
		UserRole = userRole;
	}

}
