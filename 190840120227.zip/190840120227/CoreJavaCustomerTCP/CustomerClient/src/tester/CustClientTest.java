package tester;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.Scanner;

public class CustClientTest {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in); Socket s1 = new Socket("localhost", 7070);) {

			boolean exit = false;
			try (DataOutputStream out = new DataOutputStream(s1.getOutputStream());
					DataInputStream in = new DataInputStream(s1.getInputStream());
					ObjectInputStream ino = new ObjectInputStream(s1.getInputStream())) {
				while (!exit) {
					System.out.println("1. Enter Username Password to update Address & Mobile Number");
					System.out.println("2. Enter City to get the List of Customers");
					System.out.println("0. Exit");
					System.out.println("Enter choice:");
					try {
						switch (sc.nextInt()) {
						case 1: {
							out.writeInt(1);
							System.out.println("Enter email");
							out.writeUTF(sc.next());
							System.out.println("Enter Password");
							out.writeUTF(sc.next());
							System.out.println("Enter New City");
							out.writeUTF(sc.next());
							System.out.println("Enter New Mobile Number");
							out.writeUTF(sc.next());
							System.out.println("Status:" + in.readUTF());
						}
							break;
						case 2: {
							out.writeInt(2);
							System.out.println("Enter City");
							out.writeUTF(sc.next());
							System.out.println(in.readUTF());
							System.out.println(in.readUTF());
						}
							break;
						case 0:
							exit = true;
							break;
						}

					} catch (Exception e) {
						sc.nextLine();
						e.printStackTrace();
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
