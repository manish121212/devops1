package com.app.core;

import java.time.LocalDate;

public class CustomerClient {
	private String email, password, city, mobileno;
	private LocalDate dob;

	public CustomerClient(String email, String password, String city, String mobileno, LocalDate dob) {
		super();
		this.email = email;
		this.password = password;
		this.city = city;
		this.mobileno = mobileno;
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "CustomerClient [email=" + email + ", password=" + password + ", city=" + city + ", mobileno=" + mobileno
				+ ", dob=" + dob + "]";
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

}
