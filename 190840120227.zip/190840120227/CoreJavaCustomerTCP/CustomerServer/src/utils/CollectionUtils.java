package utils;

import java.time.LocalDate;
import java.util.HashMap;

import com.app.core.CustomerClient;

public class CollectionUtils {

	public static HashMap<String, CustomerClient> getClientList() {
		HashMap<String, CustomerClient> hmap = new HashMap<String, CustomerClient>();
		CustomerClient c1 = new CustomerClient("abc1@gmail.com", "abc123", "pune", "9876543210",
				LocalDate.parse("1999-11-11"));
		CustomerClient c2 = new CustomerClient("abc2@gmail.com", "abc123", "pune", "9876543210",
				LocalDate.parse("1999-11-12"));
		CustomerClient c3 = new CustomerClient("abc3@gmail.com", "abc123", "mumbai", "9876543210",
				LocalDate.parse("1999-11-13"));
		CustomerClient c4 = new CustomerClient("abc4@gmail.com", "abc123", "hyderabad", "9876543210",
				LocalDate.parse("1999-11-14"));
		CustomerClient c5 = new CustomerClient("abc5@gmail.com", "abc123", "pune", "9876543210",
				LocalDate.parse("1999-01-15"));

		hmap.put(c1.getEmail(), c1);
		hmap.put(c2.getEmail(), c2);
		hmap.put(c3.getEmail(), c3);
		hmap.put(c4.getEmail(), c4);
		hmap.put(c5.getEmail(), c5);

		return hmap;
	}

}
