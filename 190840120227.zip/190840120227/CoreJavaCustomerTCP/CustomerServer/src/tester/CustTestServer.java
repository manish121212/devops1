package tester;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import com.app.core.CustomerClient;

import cust_exception.ClientHandlingExcept;

import static utils.CollectionUtils.*;

public class CustTestServer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			HashMap<String, CustomerClient> hmap = getClientList();

			try (ServerSocket ss = new ServerSocket(7070, 10); Socket ds = ss.accept();) {

				System.out.println(ds);

				try (DataOutputStream out = new DataOutputStream(ds.getOutputStream());
						ObjectOutputStream outo = new ObjectOutputStream(ds.getOutputStream())) {
					out.flush();
					DataInputStream in = new DataInputStream(ds.getInputStream());
					while (true) {
						switch (in.readInt()) {
						case 1: {
							try {
								// Getting cust via Email
								CustomerClient c = hmap.get(in.readUTF());
								// Getting password
								String pass = in.readUTF();
								// Getting City & Mobile No.
								String city = in.readUTF();
								String mno = in.readUTF();

								String msg = "Invalid login";
								// Authenticating Client
								if (c != null) {
									if (c.getPassword().equals(pass)) {
										// Updating City & Mobile No.
										c.setCity(city);
										c.setMobileno(mno);
										msg = "Updation Sucessfull";
									}
								}
								// Sending Response msg
								out.writeUTF(msg);
							} catch (Exception e) {
								throw new ClientHandlingExcept(e.getMessage());
							}
						}
							break;

						case 2: {
							try {
								// Getting City Name from Client
								String city = in.readUTF();
								List<CustomerClient> temp = new ArrayList<>();
								for (CustomerClient c : hmap.values()) {
									System.out.println(c);
									// Storing Cust from same city to temp list
									if (c.getCity().equalsIgnoreCase(city))
										temp.add(c);
								}
								out.writeUTF("Customers from City:" + city);

								// Sorting List as per DOB
								Collections.sort(temp, new Comparator<CustomerClient>() {

									@Override
									public int compare(CustomerClient o1, CustomerClient o2) {
										return o1.getDob().compareTo(o2.getDob());
									}
								});

								String custlist = "";
								for (CustomerClient cust : temp) {
									custlist = custlist + cust.toString() + "  ";
								}
								// Sending Response data
								out.writeUTF(custlist);
							} catch (Exception e) {
								throw new ClientHandlingExcept(e.getMessage());
							}
						}
							break;
						default:
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}