package cust_exception;

public class ClientHandlingExcept extends Exception {

	public ClientHandlingExcept(String errmsg) {
		super(errmsg);
		System.out.println(errmsg);
	}

}
